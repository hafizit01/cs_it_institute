from django.urls import path
from .views import *
urlpatterns = [
    path('', index, name='index'),
    path('course/<slug:slug>/', course_detail, name='course_detail'),
    path('teacher/<slug:slug>/', teacher_details, name='teacher_details'),

]