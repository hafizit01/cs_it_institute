from django.shortcuts import render, get_object_or_404
from .models import *

# Create your views here.
def index(request):
    
    category = Category.objects.all()
    course = Course.objects.all()
    teacher = Teacher.objects.all()
    testimonial = Testmonial.objects.all()
    context = {
        'course':course,
        'teacher':teacher,
        'category':category,
        'testimonial':testimonial,
    }
    return render(request, 'main_app/index.html',context)


def course_detail(request,slug):
    course = get_object_or_404(Course, slug=slug)
    context = {
        'course':course
    }
    return render(request, 'main_app/course_detail.html', context)


def teacher_details(request,slug):
    teacher = get_object_or_404(Teacher, slug=slug)
    context={
        'teacher':teacher
    }
    return render(request, 'main_app/teacher_details.html', context)


def custom_404_view(request,exception):
    return render(request, 'main_app/404.html', status=504)